<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CtCC extends Model
{
    protected $table = "staff_ct_cc_allotment";
    public $timestamps = false;
}
