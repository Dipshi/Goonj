<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Course_map extends Model
{
    protected $table = "exam_course_map";
    //protected $primaryKey = "course_code";
    public $timestamps =false;
}
