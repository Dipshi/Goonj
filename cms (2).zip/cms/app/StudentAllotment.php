<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentAllotment extends Model
{
    protected $table="student_allotment";
    protected $primarykey = "student_allotment_uid";
    
}
