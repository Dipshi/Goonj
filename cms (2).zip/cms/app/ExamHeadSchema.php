<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExamHeadSchema extends Model
{
    protected $table = 'exam_head_schema';
}
