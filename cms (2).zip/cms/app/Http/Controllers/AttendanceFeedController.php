<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\AttendanceRecord;

class AttendanceFeedController extends Controller
{
	/******************************************************************************************
     * This return an array of associatinve array.
	 * Each sub array contains the record of one student for the SubAllotId with the records withing the passed dates and the complied data.
	 * This object is used in excel export function to provide the user with data for a subject between two dates
     *
     * @param  int  $id
	 * @param  date $s_date
	 * @param  date $e_date
     * @return \Illuminate\Http\Response
     *******************************************************************************************/
    public static function getSubjectReport($id, $s_date, $e_date,$course){ 
		//echo $id."-".$s_date."-".$e_date;
    	$result =  DB::select('CALL generateReports('.$id.', \''.$s_date.'\',\''.$e_date.'\')'); 
		//print_r($result);
		$dates = DB::select('Select uid, date, contact_head_meeting_index, attendance from student_attendance_record where sub_allotment_id = '.$id.' and date between \''.$s_date.'\' and \''.$e_date.'\' order by uid, date, contact_head_meeting_index asc'); 
	  	$unique_dates = DB::select('select distinct date, contact_head_meeting_index from student_attendance_record where sub_allotment_id = '.$id.' and date between \''.$s_date.'\' and \''.$e_date.'\' order by date, contact_head_meeting_index asc' );
		//$syllabus=DB::select('select distinct contact_head from subject_allotment  where sub_allotment_id='.$id.'');
		$syllabus=collect(DB::select('select contact_head,count(CASE WHEN attendance = 1 then 1 ELSE NULL END) as total from student_attendance_record,student,student_allotment,subject_allotment where student_attendance_record.sub_allotment_id = '.$id.' and student_allotment.term_id = subject_allotment.term_id  and student.UID = student_attendance_record.UID and student_allotment.uid = student.uid and subject_allotment.sub_allotment_id ='.$id.' group by student.UID,subject_allotment.contact_head'));
		$return_value = array();
		for ($i=0; $i < count($result); $i++) {
			$temp = (array)$result[$i]; 
			$curr_uid = $temp["UID"]; 
            $u_id=$temp["Present"];
			 $temp1=$temp["contact_head_hours"];
			foreach($unique_dates as $unique_date) {
				$curr_date = $unique_date->date;
				$index = date("d-m", strtotime($curr_date));;
				$append = $unique_date->contact_head_meeting_index == 1?"":"(".$unique_date->contact_head_meeting_index.")";
				
				$temp[$index.''.$append] = "-";
				for ($j=0; $j < count($dates); $j++) {
					if ($dates[$j]->uid == $curr_uid && $dates[$j]->date == $unique_date->date && $dates[$j]->contact_head_meeting_index == $unique_date->contact_head_meeting_index) { 
						$temp[$index.''.$append] = $dates[$j]->attendance; 
					}
				}
			 foreach($syllabus as $s){
			  	$temp[$s->contact_head]=$s->total;
			  }
			$per=($u_id*100)/(4*$temp1);
			$temp["percentage_attendance"]=$per;
				$temp["course"] = $course;
				$return_value[$i] = (array)$temp; 
				
			} 
	
		return $return_value;
	}
	}
	
	public function generateReport($term,$s_date,$e_date)
	{	
		
	    $result = DB::select('CALL generateReports(17043, \''.$s_date.'\',\''.$e_date.'\')'); 
		//stored procedure returns 
	    $sub_allot=collect(DB::select("Select sub_allotment_id,course_code from subject_allotment where term_id LIKE '%%%$term'"));//fetching suballotment id's of the  dept of staff 
		$return_value = array();
		for ($i=0; $i < count($result); $i++)
		 {

			$temp = (array)$result[$i]; 
			$curr_uid = $temp["UID"]; 
			foreach($sub_allot as $s){
				$query1=collect(DB::select('CALL Report('.$s->sub_allotment_id.', \''.$s_date.'\',\''.$e_date.'\','.$curr_uid.',17043)'));
					if($query1->isEmpty())
					{
						$answer=collect(DB::select("SELECT distinct(course_name),contact_head FROM `subject_allotment` as sa ,exam_course_map as e where sa.term_id=e.term_id and sa.course_code=e.course_code and sub_allotment_id=$s->sub_allotment_id and e.term_id=17043"));
						foreach($answer as $ans){
						$temp[$ans->course_name.'-'.$ans->contact_head]= "-";
						}
					}
					else{
					foreach($query1 as $q){
						
							$temp[$q->course_name.'-'.$q->contact_head]= $q->total;							
					}
					}
				}
					$return_value[$i] = (array)$temp;
					
			}
			//print_r($return_value);
			 return $return_value;
			  
		 
	}
}
	