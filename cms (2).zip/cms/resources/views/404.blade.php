@extends('layouts.plane')

<div class="page-container">
    <div class="jumbotron">
        <h4>404 Error!</h4>
        <p>This site configured at this address does not contain the requested file.</p>
        <a href="/" class="btn btn-info" role="button">Let's get you back to the Dashboard</a>
    </div>
</div>
{{-- @stop --}}