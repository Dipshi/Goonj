@extends('student.layouts.dashboard')
@section('page_heading','Apply for Railway Concession')
@section('section')
    <!-- Your Code Here -->
@stop