@extends('student.layouts.dashboard')
@section('page_heading','Apply for Bonafide')
@section('section')
    <!-- Your Code Here -->
@stop