@extends('student.layouts.dashboard')
@section('page_heading','Attendance')
@section('section')
    <!-- Your Code Here -->
@stop