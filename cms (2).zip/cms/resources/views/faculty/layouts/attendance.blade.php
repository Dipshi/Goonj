@extends('faculty.layouts.dashboard')
@section('page_heading','Student Attendance')
@section('section')

{{-- To add the Student attendance template here --}}
    @yield('content')

@stop