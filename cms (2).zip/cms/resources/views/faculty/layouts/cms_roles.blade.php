<?php

// Types
define("STAFF", 1);

// Roles
define("HOD", 3);
define("TIMEINC", 4);
?>