@extends('faculty.layouts.attendance')
@section('page_heading','Select Date')
@section('content')
<div class="container">
	<div class="row"> 
		@if($request->submit == 'View')
			<h3>Show attendance by date: </h3><br>
		@else
			<h3 class="col-sm-offset-3 col-xs-offset-1">Select date: </h3><br>
		@endif
		<div class="col-sm-10 col-sm-offset-1">
			{!! Form::open(['action'=>'StudentAttendanceController@control', 'method'=>'POST']) !!}
				<div class="col-sm-offset-2 col-sm-4">
					<div class="form-group ">
						@if(strtotime($Date['end_date']) > time())
							<input class="form-control text-center input-lg" id="date" name="Date" max="{{date("Y")}}-{{date("m")}}-{{date("d")}}" min="{{$Date['start_date']}}" onfocus="(this.type='date')" onblur="(this.type='text')" placeholder="ENTER DATE" value="{{date("Y")}}-{{date("m")}}-{{date("d")}}" required/>
						@else
							<input class="form-control text-center input-lg" id="date" name="Date" max="{{$Date['end_date']}}" min="{{$Date['start_date']}}" onfocus="(this.type='date')" onblur="(this.type='text')"  placeholder="ENTER DATE" value="{{date("Y")}}-{{date("m")}}-{{date("d")}}" required/>
						@endif
					</div>
					<input type="hidden" name="SubAllotId" value="{{$request->SubAllotId}}">
					<input type="hidden" name="TermID" value="{{$request->TermID}}">
					<input type="hidden" name="Division" value="{{$request->Division}}">
					<input type="hidden" name="ContactHead" value="{{$request->ContactHead}}">
					<input type="hidden" name="submit" value="{{$request->submit}}">

				</div>
				<div class="col-sm-2">
					<button type="submit" name="next" class="btn btn-danger btn-lg" value="submit">Next</button>
				</div>	
			{!! Form::close() !!}
		</div>
	</div>
	</div>
	@if($request->submit == 'View')
		<hr>
		<h3>Download Class report</h3><br>
		<div class="row">
		{!! Form::open(['action'=>'StudentAttendanceController@retrieveexcel', 'method'=>'POST']) !!}
			<div class="col-sm-10 col-sm-offset-1">
				<div class="col-sm-4 col-sm-offset 1">
					<div class="form-group">
					<label>From Date:</label>
						@if(strtotime($Date['end_date']) > time())
							<input class="form-control text-center  input-lg" id="date" name="SDate" max="{{date("Y")}}-{{date("m")}}-{{date("d")}}" min="{{$Date['start_date']}}" onfocus="(this.type='date')" onblur="(this.type='text')" placeholder="ENTER DATE" value="{{date("Y")}}-{{date("m")}}-{{date("d")}}" required/>
						@else
							<input class="form-control text-center" id="date" name="SDate" max="{{$Date['end_date']}}" min="{{$Date['start_date']}}" onfocus="(this.type='date')" onblur="(this.type='text')"  placeholder="ENTER DATE" value="{{date("Y")}}-{{date("m")}}-{{date("d")}}" required/>
						@endif
					</div>
				</div>
				<div class="col-sm-4">
					<div class="form-group">
					<label>To Date:</label>
						@if(strtotime($Date['end_date']) > time())
							<input class="form-control text-center  input-lg" id="date" name="EDate" max="{{date("Y")}}-{{date("m")}}-{{date("d")}}" min="{{$Date['start_date']}}" onfocus="(this.type='date')" onblur="(this.type='text')" placeholder="ENTER DATE" value="{{date("Y")}}-{{date("m")}}-{{date("d")}}" required/>
						@else
							<input class="form-control text-center  input-lg" id="date" name="EDate" max="{{$Date['end_date']}}" min="{{$Date['start_date']}}" onfocus="(this.type='date')" onblur="(this.type='text')"  placeholder="ENTER DATE" value="{{date("Y")}}-{{date("m")}}-{{date("d")}}" required/>
						@endif
					</div>
				</div>
				<div class="col-sm-2">
					<br>
					<button type="submit" name="next" class="btn btn-danger btn-lg" value="submit">Download Report</button>
				</div>
			</div>
			<input type="hidden" name="SubAllotId" value="{{$request->SubAllotId}}">
		{!! Form::close() !!}
		</div> 
	@endif
@stop