@extends('faculty.layouts.dashboard')
@section('page_heading','Courses Taught')
@section('section')
    {{$url}}
    <img src="{{$url}}" class="img-rounded">
@stop
