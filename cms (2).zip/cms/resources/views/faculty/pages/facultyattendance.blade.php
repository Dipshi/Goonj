@extends('faculty.layouts.dashboard')
@section('page_heading','Faculty Attendance')
@section('section')
                 
@stop