@extends('faculty.layouts.dashboard')
@section('page_heading','Transcript Approval')
@section('section')

@stop