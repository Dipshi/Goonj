@extends('faculty.layouts.dashboard')
@section('page_heading','Roles and Responsibilities')
@section('section')
                 
@stop
