@extends('faculty.layouts.dashboard')
@section('page_heading','Leaving Certificate Approval')
@section('section')

@stop