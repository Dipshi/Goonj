@extends('faculty.layouts.dashboard')
@section('page_heading','Bonafide Approval')
@section('section')

@stop