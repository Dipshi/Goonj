<p><ul class="nav nav-{{$class}}">
  <li role="presentation" class="active"><a href="#">Home</a></li>
  <li role="presentation"><a href="#">Profile</a></li>
  <li class="disabled" role="presentation"><a href="#">Messages</a></li>
</ul>
</p>