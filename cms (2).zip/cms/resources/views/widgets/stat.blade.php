
<div class="stats">
<div class="bg-{{$color}}">
		<div class=""><i class="fa fa-{{ $icon }} fa-5x"></i></div>
		<h3 align="center">{{ $value }}</h3>
		<p>{{ $header }}</p>	
		<a href="{{ $href }}">View details <i class="fa fa-arrow-circle-right"></i></a>
	</div>
</div>
