@extends('layouts.dashboard')
@section('page_heading','Dashboard')
@section('section')
           
@stop
