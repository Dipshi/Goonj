<?php $__env->startSection('page_heading','Application Status'); ?>
<?php $__env->startSection('section'); ?>
<div class="panel-body">
<div class="alert alert-success " role="alert">
	 <i class="fa fa-check"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Successfully applied!!!
</div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>