<?php $__env->startSection('page_heading','Assign Roll'); ?>
<?php $__env->startSection('section'); ?>


<div class = "col-sm-12">
    <?php if(isset($details)): ?>
        <?php if(count($count)>1): ?>
            <table class="table table-hover">
                <tr>
                    <th>Sr No</th>
                    <th>UID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Roll no.</th>
                </tr>
                
                <?php for($i=0; $i<count($details); $i++): ?>
                <tr>
                    <td><?php echo e($i+1); ?></td>
                    <td><?php echo e($details[$i]->UID); ?></td>
                    <td><?php echo e($details[$i]->FirstName); ?></td>
                    <td><?php echo e($details[$i]->LastName); ?></td>
                    <td>
                        <input class="form-control" type="number" value="<?php echo e($i+1); ?>"></input>
                    </td>
                </tr>
                <?php endfor; ?>
            </table>
            <div class="row">
                <div class="text-center">
                    <?php echo e(Form::open(['action'=>'ClassTeacherController@assign_roll', 'method'=>'post'])); ?>

                    <?php echo e(Form::submit('Submit',['class' =>'btn btn-success' , 'name'=>'insert'])); ?>

                    <?php echo e(Form::close()); ?>

                </div>    
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="col-sm-6 col-md-6">
            <div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
                    ×</button>
                <span class="glyphicon glyphicon-hand-right"></span> <strong>Can't Assign Roll nos.</strong>
                <hr class="message-inner-separator">
                <p>
                    <table>
                        <tr>
                            <th>Sr No</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                        </tr>
                        <?php for($i=0; $i<count($details); $i++): ?>
                            <tr>
                                <td><?php echo e($i+1); ?></td>
                                <td><?php echo e(@$detail->FirstName); ?></td>
                                <td><?php echo e(@$detail->LastName); ?></td>
                            </tr>
                        <?php endfor; ?>
                    </table>
                </p>
            </div>
        </div>   
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('faculty.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>