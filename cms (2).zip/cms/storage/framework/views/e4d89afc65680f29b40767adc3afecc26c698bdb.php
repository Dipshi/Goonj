<?php $__env->startSection('page_heading','Pre Academics'); ?>
<?php $__env->startSection('section'); ?>
<!-- This page is for preadcademic details for DSE  -->
<h3 align="center">Secondary School Certificate</h3>
<?php echo Form::open(['method'=>'POST']); ?>


<div class="container">
        <div class="form-group" style="padding:0 0 0 1.2%">
                <?php echo e(Form::label('schoolname','School Name')); ?>

                <?php echo e(Form::text('schoolName','Model English School',['class' => 'form-control','disabled'])); ?>

        </div>

        <div class="form-group ">
        <div class="col-xs-3">
                <?php echo e(Form::label('totalmarks','Total Marks')); ?>

                <?php echo e(Form::text('totalMarks','488.67',['class' => 'form-control','disabled'])); ?>

        </div>
        </div>

        <div class="form-group">
        <div class="col-xs-3">
                <?php echo e(Form::label('outof','Out Of')); ?>

                <?php echo e(Form::text('outOf','650',['class' => 'form-control','disabled'])); ?>

        </div>
        </div>
        <div class="form-group">
        <div class="col-xs-3">
                <?php echo e(Form::label('percentageo','Percentage obtained')); ?>

                <?php echo e(Form::text('percentage',$dsePreAcademics->SSC,['class' => 'form-control','disabled'])); ?>

        </div>
        </div>
        <br>
        <br><br>

        <h3 align="center">Direct Second Year Certificate</h3>
        <div class="form-group" style="padding:0 0 0 1.2%">
                <?php echo e(Form::label('juniorclg','Junior College Name')); ?>

                <?php echo e(Form::text('juniorClg','MH Junior College and High School',['class' => 'form-control','disabled'])); ?>

        </div>
       <div class="container" style="padding:0 0 0 0.6%">
                <div class="form-group">
                        <div class="col-xs-3">
                                <?php echo e(Form::label('semfive','SEM 5 ')); ?>

                                <?php echo e(Form::text('semFive',$dsePreAcademics->SEM5,['class' =>'form-control','disabled'])); ?>

                        </div>
                        <div class="col-xs-3">
                                <?php echo e(Form::label('semsix','SEM 6')); ?>

                                <?php echo e(Form::text('semSix',$dsePreAcademics->SEM6,['class' => 'form-control','disabled'])); ?>

                        </div>
                        
                </div>
        </div>
        <br>
      

<br>
<?php echo Form::close(); ?>

 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>