<?php $__env->startSection('page_heading','Current Academics'); ?>
<?php $__env->startSection('section'); ?>
<ul class="timeline">
    
    <li><div class="tldate">First Year</div></li>
    <li>
        <div class="timeline-badge"><i class="fa fa-check"></i>
        </div>
        <div class="timeline-panel">
            <div class="timeline-heading">
                <a href="<?php echo e(route('report', ['id' => 1])); ?>"><h4 class="timeline-title">Semester 1</h4>  </a>   
            </div>
            <div class="timeline-body" style="overflow-x:auto;">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                        <th>KT</th>
                        <th>Reval Application</th>
                        <th>Changes due to Reval</th>
                        <th>Cleared in Reval</th>
                        <th>Pass/Fail</th>
                        <th>CGPA</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>0</td>
                            <td>Otto</td>
                            <td>@mdo</td>
                            <td>@mdo</td>
                            <td>@mdo</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </li>
    
    <li class="timeline-inverted">
        <div class="timeline-badge warning"><i class="fa fa-credit-card"></i>
        </div>
        <div class="timeline-panel">
            <div class="timeline-heading">
                <h4 class="timeline-title">Semester 2</h4>
            </div>
            <div class="timeline-body" style="overflow-x:auto;">
            <table class="table table-bordered">
                <thead>
                    <tr>
                    <th>KT</th>
                    <th>Reval Application</th>
                    <th>Changes due to Reval</th>
                    <th>Cleared in Reval</th>
                    <th>Pass/Fail</th>
                    <th>CGPA</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>0</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                    </tr>
                </tbody>
            </table>
            </div>
        </div>
    </li>
    
    
    <li>
        <div class="timeline-badge"><i class="fa fa-check"></i>
        </div>
        <div class="timeline-panel">
            <div class="timeline-heading">
                <h4 class="timeline-title">Semester 3</h4>     
            </div>
            <div class="timeline-body" style="overflow-x:auto;">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                        <th>KT</th>
                        <th>Reval Application</th>
                        <th>Changes due to Reval</th>
                        <th>Cleared in Reval</th>
                        <th>Pass/Fail</th>
                        <th>CGPA</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>0</td>
                            <td>Otto</td>
                            <td>@mdo</td>
                            <td>@mdo</td>
                            <td>@mdo</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </li>
    
    <li class="timeline-inverted">
        <div class="timeline-badge"><i class="fa fa-credit-card"></i>
        </div>
        <div class="timeline-panel">
            <div class="timeline-heading">
                <h4 class="timeline-title">Semester 4</h4>
            </div>
            <div class="timeline-body" style="overflow-x:auto;">
            <table class="table table-bordered">
                <thead>
                    <tr>
                    <th>KT</th>
                    <th>Reval Application</th>
                    <th>Changes due to Reval</th>
                    <th>Cleared in Reval</th>
                    <th>Pass/Fail</th>
                    <th>CGPA</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>0</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                    </tr>
                </tbody>
            </table>
            </div>
        </div>
    </li>

    
    <li>
        <div class="timeline-badge"><i class="fa fa-check"></i>
        </div>
        <div class="timeline-panel">
            <div class="timeline-heading">
                <h4 class="timeline-title">Semester 5</h4>     
            </div>
            <div class="timeline-body" style="overflow-x:auto;">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                        <th>KT</th>
                        <th>Reval Application</th>
                        <th>Changes due to Reval</th>
                        <th>Cleared in Reval</th>
                        <th>Pass/Fail</th>
                        <th>CGPA</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>0</td>
                            <td>Otto</td>
                            <td>@mdo</td>
                            <td>@mdo</td>
                            <td>@mdo</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </li>
    
    <li class="timeline-inverted">
        <div class="timeline-badge warning"><i class="fa fa-credit-card"></i>
        </div>
        <div class="timeline-panel">
            <div class="timeline-heading">
                <h4 class="timeline-title">Semester 6</h4>
            </div>
            <div class="timeline-body" style="overflow-x:auto;">
            <table class="table table-bordered">
                <thead>
                    <tr>
                    <th>KT</th>
                    <th>Reval Application</th>
                    <th>Changes due to Reval</th>
                    <th>Cleared in Reval</th>
                    <th>Pass/Fail</th>
                    <th>CGPA</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>0</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                    </tr>
                </tbody>
            </table>
            </div>
        </div>
    </li>
    
    <li>
        <div class="timeline-badge"><i class="fa fa-check"></i>
        </div>
        <div class="timeline-panel">
            <div class="timeline-heading">
                <h4 class="timeline-title">Semester 7</h4>     
            </div>
            <div class="timeline-body" style="overflow-x:auto;">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                        <th>KT</th>
                        <th>Reval Application</th>
                        <th>Changes due to Reval</th>
                        <th>Cleared in Reval</th>
                        <th>Pass/Fail</th>
                        <th>CGPA</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>0</td>
                            <td>Otto</td>
                            <td>@mdo</td>
                            <td>@mdo</td>
                            <td>@mdo</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </li>
    
    <li class="timeline-inverted">
        <div class="timeline-badge warning"><i class="fa fa-credit-card"></i>
        </div>
        <div class="timeline-panel">
            <div class="timeline-heading">
                <h4 class="timeline-title">Semester 8</h4>
            </div>
            <div class="timeline-body" style="overflow-x:auto;">
            <table class="table table-bordered">
                <thead>
                    <tr>
                    <th>KT</th>
                    <th>Reval Application</th>
                    <th>Changes due to Reval</th>
                    <th>Cleared in Reval</th>
                    <th>Pass/Fail</th>
                    <th>CGPA</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>0</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                    </tr>
                </tbody>
            </table>
            </div>
        </div>
    </li>
</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>