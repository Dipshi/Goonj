 
<?php $__env->startSection('page_heading','Defaulter List'); ?> 
<?php $__env->startSection('section'); ?> 



	 <div class="row">
		<?php echo e(Form::open(['action'=>'Councellor@attendance_report', 'method'=>'GET'])); ?>

		<div class="col-sm-6">
			<div class="form-group">
				<select name="department" class="form-control">				   
			
			
		  <option value="34">Inft-3</option> 
          <option value="56">Extc-5</option> 
          <option value="78">ETRX-7</option> 
				</select>
				
			</div>
		</div>
		
		<div class="col-sm-2">
			<div class="form-group">
				<?php echo e(Form::date('SDate','',['class'=>'form-control','palceholder'=>'From','name'=>'SDate'])); ?>

			</div>
		</div>
		<div class="col-sm-2">
			<div class="form-group">
				<?php echo e(Form::date('EDate','',['class'=>'form-control','palceholder'=>'To','name'=>'EDate'])); ?>

			</div>
		</div>
		<?php echo e(Form::submit('Search', ['class'=>'btn btn-success',"name"=>"Search"])); ?>

		<?php echo e(Form::close()); ?>

	</div> 

 



				
						
		

<?php $__env->stopSection(); ?>
<?php echo $__env->make('faculty.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>