<?php $__env->startSection('page_heading','Apply for Leaving Certificate'); ?>
<?php $__env->startSection('section'); ?>
    <!-- Your Code Here -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.0/css/bootstrapValidator.min.css"/>
<script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.0/js/bootstrapValidator.min.js"> </script>
<script>//Script for file upload
$(function() {

  // We can attach the `fileselect` event to all file inputs on the page
  $(document).on('change', ':file', function() {
    var input = $(this),
        numFiles = input.get(0).files ? input.get(0).files.length : 1,
        label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
    input.trigger('fileselect', [numFiles, label]);
  });

  // We can watch for our custom `fileselect` event like this
  $(document).ready( function() {
      $(':file').on('fileselect', function(event, numFiles, label) {

          var input = $(this).parents('.input-group').find(':text'),
              log = numFiles > 1 ? numFiles + ' files selected' : label;

          if( input.length ) {
              input.val(log);
          } else {
              if( log ) alert(log);
          }

      });
  });

}); 
</script>

<?php if($students->TypeOfAdmission==0): ?> <!--If student's type of admission is FE -->
<?php echo Form::open(['method'=>'POST']); ?>

<div class="col-sm-1"></div>
<div class="col-sm-10">
	<div class="jumbotron ">
		<div class="container-fluid bg-3 ">
			<div class="col-sm-1"></div>
			<div class="col-sm-10">
				<div class="form-group">
						<?php echo e(Form::date('appdate',\Carbon\Carbon::now(),['class' => 'form-control','placeholder'=>'Application Date','disabled'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('stuname',$students->FirstName.' '.$students->LastName,['class' => 'form-control','placeholder'=>'Student Name','disabled'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::number('phoneno',$students->MobileNo,['class' => 'form-control','placeholder'=>'Mobile Number','disabled'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::date('dob',$students->DOB,['class' => 'form-control','placeholder'=>'Date of Birth','disabled'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('branch',$students->Branch,['class' => 'form-control','placeholder'=>'Branch','disabled'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('academicyearAdmission',$students->AdmissionYear,['class' => 'form-control','placeholder'=>'Academic Year Of Admission','disabled'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('yearofPass', '',['class' => 'form-control','placeholder'=>'Year of Passing' ,'required'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('percentage', '',['class' => 'form-control','placeholder'=>'Percentage','required'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('caste',$students->Category,['class' => 'form-control','placeholder'=>'Caste','disabled'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('subCaste', '',['class' => 'form-control','placeholder'=>'Sub-Caste','required'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('feDse', 'FE',['class' => 'form-control','placeholder'=>'First year of admission/ Direct year of admission','disabled'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('lastSchname', '',['class' => 'form-control','placeholder'=>'Last School Name','required'])); ?>

				</div>
				<!--feild for uploading signatue-->
				<div class="input-group">
						<label class="input-group-btn btn-primary">
							<span class="btn btn-custom">
									Upload signature <input type="file" style="display: none;" name="Signature" id="Signature"  required >
							</span>
						</label>
						<input type="text" class="form-control" readonly>
				</div>
				<br>
				<!-- Feilds for uploading documents -->
				<div class="input-group">
						<label class="input-group-btn btn-primary">
							<span class="btn btn-custom">
									Upload BE Marksheet Xerox <input type="file" style="display: none;" name="Signature" id="Signature"  required >
							</span>
						</label>
						<input type="text" class="form-control" readonly>
				</div>
				<br>
				
				<div class="input-group">
						<label class="input-group-btn btn-primary">
							<span class="btn btn-custom">
									Upload BE Passing Certificate <input type="file" style="display: none;" name="Signature" id="Signature"  required >
							</span>
						</label>
						<input type="text" class="form-control" readonly>
				</div>
				<br>
				<div class="input-group">
						<label class="input-group-btn btn-primary">
							<span class="btn btn-custom">
									Upload Nationality Proof <input type="file" style="display: none;" name="Signature" id="Signature"  required >
							</span>
						</label>
						<input type="text" class="form-control" readonly>
				</div>
				<br>              
				<div class="input-group">
						<label class="input-group-btn btn-primary">
							<span class="btn btn-custom">
									Upload Previous Leaving Xerox <input type="file" style="display: none;" name="Signature" id="Signature"  required >
							</span>
						</label>
						<input type="text" class="form-control" readonly>
				</div>
				<br><br>
				<?php echo e(Form::submit('APPLY',['class'=>'btn btn-success btn-block'])); ?>

				</div>
			</div>
			<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</div>
<?php else: ?> <!-- If student's type of admission is DSE --> 
 <?php echo Form::open(['method'=>'POST']); ?>

<div class="col-sm-1"></div>
<div class="col-sm-10">
	<div class="jumbotron ">		
		<div class="container-fluid bg-3 ">
			<div class="col-sm-2"></div>
			<div class="col-sm-8">
				<div class="form-group">
						<?php echo e(Form::date('appdate',\Carbon\Carbon::now(),['class' => 'form-control','placeholder'=>'Application Date','disabled'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('stuname',$students->FirstName.' '.$students->LastName,['class' => 'form-control','placeholder'=>'Student Name','disabled'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::number('phoneno',$students->MobileNo,['class' => 'form-control','placeholder'=>'Mobile Number','disabled'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::date('dob',$students->DOB,['class' => 'form-control','placeholder'=>'Date of Birth','disabled'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('branch',$students->Branch,['class' => 'form-control','placeholder'=>'Branch','disabled'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('academicyearAdmission',$students->AdmissionYear,['class' => 'form-control','placeholder'=>'Academic Year Of Admission','disabled'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('yearofPass', '',['class' => 'form-control','placeholder'=>'Year of Passing' ,'required'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('percentage', '',['class' => 'form-control','placeholder'=>'Percentage','required'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('caste',$students->Category,['class' => 'form-control','placeholder'=>'Caste','disabled'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('subCaste', '',['class' => 'form-control','placeholder'=>'Sub-Caste','required'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('feDse', 'DSE',['class' => 'form-control','placeholder'=>'First year of admission/ Direct year of admission','disabled'])); ?>

				</div>
				<div class="form-group">
						<?php echo e(Form::text('lastSchname', '',['class' => 'form-control','placeholder'=>'Last School Name','required'])); ?>

				</div>
				<!--feild for uploading signatue-->
				<div class="input-group">
						<label class="input-group-btn btn-primary">
							<span class="btn btn-custom">
									Upload signature <input type="file" style="display: none;" name="Signature" id="Signature"  required >
							</span>
						</label>
						<input type="text" class="form-control" readonly>
				</div>
				<br>
				<!-- Feilds for uploading documents -->
				<div class="input-group">
						<label class="input-group-btn btn-primary">
							<span class="btn btn-custom">
									Upload BE Marksheet Xerox <input type="file" style="display: none;" name="Signature" id="Signature"  required >
							</span>
						</label>
						<input type="text" class="form-control" readonly>
				</div>
				<br>
				
				<div class="input-group">
						<label class="input-group-btn btn-primary">
							<span class="btn btn-custom">
									Upload BE Passing Certificate <input type="file" style="display: none;" name="Signature" id="Signature"  required >
							</span>
						</label>
						<input type="text" class="form-control" readonly>
				</div>
				<br>
				<div class="input-group">
						<label class="input-group-btn btn-primary">
							<span class="btn btn-custom">
									Upload Nationality Proof <input type="file" style="display: none;" name="Signature" id="Signature"  required >
							</span>
						</label>
						<input type="text" class="form-control" readonly>
				</div>
				<br>              
				<div class="input-group">
						<label class="input-group-btn btn-primary">
							<span class="btn btn-custom">
									Upload Previous Leaving Xerox <input type="file" style="display: none;" name="Signature" id="Signature"  required >
							</span>
						</label>
						<input type="text" class="form-control" readonly>
				</div>
				<br><br>
				<?php echo e(Form::submit('APPLY',['class'=>'btn btn-success btn-block'])); ?>

				</div>
			</div>
			<?php echo Form::close(); ?>

			</div>
		</div>
	</div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>