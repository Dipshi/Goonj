 
<?php $__env->startSection('page_heading','Defaulter List'); ?> 
<?php $__env->startSection('section'); ?> 



	 <div class="row">
		<?php echo e(Form::open(['action'=>'Councellor@attendance_report', 'method'=>'GET'])); ?>

		<div class="col-sm-6">
			<div class="form-group">
				<select name="department" class="form-control">
				   <?php $__currentLoopData = $sem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($s); ?>"><?php echo e($dept_name1); ?>-<?php echo e($s); ?></option>
					
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
		</div>
		
		<div class="col-sm-2">
			<div class="form-group">
				<?php echo e(Form::date('fromdate','',['class'=>'form-control','palceholder'=>'From','name'=>'fromdate'])); ?>

			</div>
		</div>
		<div class="col-sm-2">
			<div class="form-group">
				<?php echo e(Form::date('todate','',['class'=>'form-control','palceholder'=>'To','name'=>'todate'])); ?>

			</div>
		</div>
		<?php echo e(Form::submit('Search', ['class'=>'btn btn-success',"name"=>"Search"])); ?>

		<?php echo e(Form::close()); ?>

	</div> 
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('faculty.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>