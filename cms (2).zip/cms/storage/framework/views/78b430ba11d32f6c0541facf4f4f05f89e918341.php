<?php $__env->startSection('page_heading','Defaulter List'); ?>
<?php $__env->startSection('section'); ?>
<script type="text/javascript">
     function configureDropDownLists(ddl1,ddl2) {
    var Inft= ['','D5', 'D10', 'D15','D20'];
    var comps= ['','D2', 'D7', 'D12','D17'];
   	var Extc= ['','D4', 'D9', 'D14','D19'];
	var Etrx= ['','D1', 'D6', 'D11','D16'];
    switch (ddl1.value) {
        case 'INFT':
            ddl2.options.length = 0;
            for (i = 0; i < Inft.length; i++) {
                createOption(ddl2, Inft[i], Inft[i]);
            }
            break;
        case 'CMPN':
            ddl2.options.length = 0; 
        for (i = 0; i < comps.length; i++) {
            createOption(ddl2, comps[i], comps[i]);
            }
            break;
        case 'EXTC':
            ddl2.options.length = 0;
            for (i = 0; i <  Extc.length; i++) {
                createOption(ddl2,  Extc[i],  Extc[i]);
            }
            break;
			case 'ETRX':
            ddl2.options.length = 0;
            for (i = 0; i <  Etrx.length; i++) {
                createOption(ddl2,  Etrx[i],  Etrx[i]);
            }
            break;

            default:
                ddl2.options.length = 0;
            break;
    }

}

    function createOption(ddl, text, value) {
        var opt = document.createElement('option');
        opt.value = value;
        opt.text = text;
        ddl.options.add(opt);
    }
</script>

<?php echo e(Form::open(['action'=>'Councellor@defaulter_list', 'method'=>'GET', 'required'])); ?>

<div class="col-sm-2">
    <div class="form-group">
        <select name="branch" class="form-control" onchange="configureDropDownLists(this,document.getElementById('ddl2'))" id="ddl1" required>
			<option value="-1">All</option>
			<option value="INFT">Information Technology</option>
			<option value="CMPN">Computer Science</option>
			<option value="ETRX">Electronics</option>
			<option value="EXTC">EXTC</option>
			<option value="INST">Intrumentation</option>
			<option value="MCA">MCA</option>
			<option value="H and S">H and S</option>
        </select>
    </div>
</div>
<div class="col-sm-2">
	<div class="form-group">
		<select id="ddl2"  class="form-control" name='department'>
		</select>
	</div>
</div>

<?php echo e(Form::submit('Search', ['class'=>'btn btn-success','name'=>'Search'])); ?>

<?php echo e(Form::close()); ?>			
<br>
<div class="container">
   <button type="button" class="btn  btn-primary" data-toggle="collapse" data-target="#demo" style="width:30%;height:50%">BE</button>
  <div id="demo" class="collapse" style="border:1px solid lightgrey;width:30%;height:70%;padding:10px">
    <a href="">50</a><br>
    <hr>
    <?php $i=0;?>
     <button type="button" class="btn  btn-default" data-toggle="collapse" data-target="#demo<?php echo $i?>" style="width:40%;height:50%;align:center;">INFT</button>
  <div id="demo<?php echo $i?>" class="collapse" style="border:1px solid lightgrey;width:40%;height:70%;padding:5px">
    <a href="">20</a>
    </div>
    <hr>
    <button type="button" class="btn  btn-default" data-toggle="collapse" data-target="#demo<?php echo $i+1?>" style="width:40%;height:50%;align:center;">INST</button>
  <div id="demo<?php echo $i+1?>" class="collapse" style="border:1px solid lightgrey;width:40%;height:70%;padding:5px">
    <a href="">30</a>
    </div>
    <hr>
     <button type="button" class="btn  btn-default" data-toggle="collapse" data-target="#demo<?php echo $i+2?>" style="width:40%;height:50%;align:center;">ETRX</button>
  <div id="demo<?php echo $i+2?>" class="collapse" style="border:1px solid lightgrey;width:40%;height:70%;padding:5px">
    <a href="">40</a>
  </div>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>