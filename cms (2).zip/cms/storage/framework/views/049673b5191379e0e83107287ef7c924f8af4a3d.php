<?php $__env->startSection('page_heading','Dashboard'); ?>
<?php $__env->startSection('section'); ?>

    <div class="col-md-7">
        <iframe src="https://calendar.google.com/calendar/embed?showTitle=0&amp;showPrint=0&amp;showCalendars=0&amp;showTz=0&amp;height=600&amp;wkst=2&amp;bgcolor=%23FFFFFF&amp;src=ves.ac.in_1h06mbn2nhd98nj3747afssvac%40group.calendar.google.com&amp;color=%23B1440E&amp;ctz=Asia%2FCalcutta" style="border-radius: 0px 0px 15px 15px" width="100%" height="500" frameborder="0" scrolling="no"></iframe>
    </div>

    <div class="page-container">
        <div class="row">
            <div class="col-sm-2 card">
                <header>Total Faculty</header>
                <p class="main">345</p>
            </div>

            <div class="col-sm-2 card">
                <header>Total Students</header>
                <p class="main">2783</p>
            </div>

            <div class="col-sm-2 card">
                <header>Teaching staff</header>
                <p class="main">221</p>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>