<?php $__env->startSection('page_heading','Pre Academics'); ?>
<?php $__env->startSection('section'); ?>
<!-- Your Code Here -->

<h3 align="center">Secondary School Certificate</h3>
<?php echo Form::open(['method'=>'POST']); ?>

<!--FE Marksheet details-->
	<div class="container">
			<div class="form-group" style="padding:0 0 0 1.2%">
				<?php echo e(Form::label('schoolname','School Name')); ?>

				<?php echo e(Form::text('schoolName','Model English School',['class' => 'form-control','disabled'])); ?>

			</div>

			<div class="form-group ">
				<div class="col-xs-3">
					<?php echo e(Form::label('totalmarks','Total Marks')); ?>

					<?php echo e(Form::text('totalMarks','488.67',['class' => 'form-control','disabled'])); ?>

				</div>
			</div>

			<div class="form-group">
				<div class="col-xs-3">
					<?php echo e(Form::label('outof','Out Of')); ?>

					<?php echo e(Form::text('outOf','650',['class' => 'form-control','disabled'])); ?>

				</div>
			</div>
			<div class="form-group">
				<div class="col-xs-3">
					<?php echo e(Form::label('percentageo','Percentage obtained')); ?>

					<?php echo e(Form::text('percentage',$preAcademics->SSC,['class' => 'form-control','disabled'])); ?>

				</div>
			</div>
<br>
<br><br><br>
<hr>
<h3 align="center">Higher Secondary School Certificate</h3>
		<div class="form-group" style="padding:0 0 0 1.2%">
				<?php echo e(Form::label('juniorclg','Junior College Name')); ?>

				<?php echo e(Form::text('juniorClg','MH Junior College and High School',['class' => 'form-control','disabled'])); ?>

		</div>
		<div class="container" style="padding:0 0 0 0.6%">
				<div class="form-group">
					<div class="col-xs-3">
						<?php echo e(Form::label('phy','Physics Marks')); ?>

						<?php echo e(Form::text('phyScore','92',['class' => 'form-control','disabled'])); ?>

					</div>
					<div class="col-xs-3">
						<?php echo e(Form::label('chem','Chemistry Marks')); ?>

						<?php echo e(Form::text('chemScore','87',['class' => 'form-control','disabled'])); ?>

					</div>
					<div class="col-xs-3">
						<?php echo e(Form::label('maths','Mathematics Marks:')); ?>

						<?php echo e(Form::text('mathsScore','98',['class' => 'form-control','placeholder'=>'Mathematics Score..','disabled'])); ?>

					</div>
				</div>
		</div>
<br>
		<div class="container" style="padding:0 0 0 0.5%">
			<div class="form-group">
				<div class="col-xs-3">
						<?php echo e(Form::label('totalmarks','Total Marks')); ?>

						<?php echo e(Form::text('totalMarks','',['class' => 'form-control','disabled'])); ?>

				</div>
				<div class="col-xs-3">
						<?php echo e(Form::label('outof','Out Of')); ?>

						<?php echo e(Form::text('outOf','650',['class' => 'form-control','disabled'])); ?>

				</div>
		       <div class="col-xs-3">
						<?php echo e(Form::label('percentage','Percentage')); ?>

						<?php echo e(Form::text('percentage',$preAcademics->HSC,['class' => 'form-control','disabled'])); ?>

		       </div>
		    </div>
		</div>
<br>
		<div class="container" style="padding:0 0 0 0.5%">
			<div class="form-group">
				<div class="col-xs-3">
						<?php echo e(Form::label('juniorclg','CET Marks')); ?>

						<?php echo e(Form::text('CetMarks',$preAcademics->CET,['class' => 'form-control','disabled'])); ?>

				</div>
				<div class="col-xs-3">
						<?php echo e(Form::label('jee','JEE Marks')); ?>

						<?php echo e(Form::text('jeeMarks',$preAcademics->JEE,['class' => 'form-control','disabled'])); ?>

				</div>
				<div class="col-xs-3">
						<?php echo e(Form::label('jeeadv','JEE Advanced Marks')); ?>

						<?php echo e(Form::text('jeeadvMarks','',['class' => 'form-control','placeholder'=>'JEE Advanced Marks','disabled'])); ?>

				</div>
			</div>
		</div>
	</div>
<br>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>