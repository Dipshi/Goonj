<?php $__env->startSection('page_heading','Student Attendance'); ?>
<?php $__env->startSection('section'); ?>

<?php use App\HelperFunctions; ?>

<?php $i=0?>

<div class="col-md-12">

<!-- <h3 id="subject_note" >Click on subject name to fill attendance</h3> -->
	<!--Card-->
	<?php if(count($subject_details)>0): ?>
		<?php $__currentLoopData = $subject_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="card col-md-4">

				

			    <!--Card content-->
			    <div class="card-block">

			        <form id="next<?php echo e($i); ?>" action="student/addattendancerecord" method="POST" onclick="execute(<?php echo e($i); ?>)"> 
						<!--Title-->
						<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
						<input type="hidden" name="suballotid" value="<?php echo e($subject_detail->sub_allotment_id); ?>">
						<input type="hidden" name="termid" value="<?php echo e($subject_detail->term_id); ?>">
				        <input type="hidden" name="div" value="<?php echo e($subject_detail->division); ?>">
						

						<h3 class="card-title" >
							<?php echo e($subject_detail->course_name); ?>

						</h3>

				        <!--Text-->
				        <div class="card-content" style="display: flex; justify-content: space-between;">
				        	<p>
							<?php echo e(HelperFunctions::getDepartment($subject_detail->term_id)); ?> - <?php echo e($subject_detail->division); ?>

						</p>

				        <p>
				        	<?php echo e(HelperFunctions::getFullContactHead($subject_detail->contact_head)); ?>

				        </p>
				        </div>
						
			        </form>
			    </div>
			   
			    <!--/.Card content-->
			    <?php $i=$i+1;?>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<!--/.Card-->
	<?php endif; ?>
	<script type="text/javascript">
		function execute(i){
			var form = document.getElementById("next"+i);
			form.submit();
		}
	</script>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('faculty.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>