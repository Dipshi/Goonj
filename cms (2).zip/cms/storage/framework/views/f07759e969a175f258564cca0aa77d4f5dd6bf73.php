<?php $__env->startSection('page_heading','Profile'); ?>
<?php $__env->startSection('section'); ?>


<div class="page-container">
    <div class="row ">
        <div class="col-sm-5">
            <h3>EID: #201</h3>
            <h2>Amit Singh</h2>
            <p class="details">amit.singh@ves.ac.in</p>
            <p class="details">9869264468</p>
            <p class="lead-details">Sr. Asst. Proffessor</p>
            <p class="details">Information Technology</p>
        </div>
        <div class="col-sm-7">
            <img src="http://via.placeholder.com/150x150">
        </div>
    </div> 
    <hr>
    <div class="row">
        <div class="col-sm-4">
            <h4 class="subtitle">Education</h4>
        </div>
        <div class="col-sm-8">
            <p class="lead-details">Bachelor of Engineering</p>
            <p class="details">Vivekanand Education Society Institute of Technology</p>
            <p class="details">Year of Completion: 2008</p>

            <p class="lead-details">Master of Engineering</p>
            <p class="details">Vivekanand Education Society Institute of Technology</p>
            <p class="details">Year of Completion: 2010</p>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-sm-4">
            <h4 class="subtitle">Jobs</h4>
        </div>
        <div class="col-sm-8">
            <p class="lead-details">Assistant Proffessor</p>
            <p class="details">2008-2012</p>

            <p class="lead-details">Sr. Asst. Proffessor</p>
            <p class="details">2012 - Present</p>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-sm-4">
            <h4 class="subtitle">Additional Details</h4>
        </div>
        <div class="col-sm-8">
            <p class="lead-details">Research Papers</p>
            <p class="details">Natural Language Processing</p>
            <p class="details">2012 - Present</p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('faculty.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>