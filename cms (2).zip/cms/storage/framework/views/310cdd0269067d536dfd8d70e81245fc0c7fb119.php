 
<?php $__env->startSection('page_heading','Defaulter List'); ?> 
<?php $__env->startSection('section'); ?>


<div class="container" >
	<div class="row">
		<?php echo e(Form::open(['action'=>'Councellor@defaulter_list', 'method'=>'GET'])); ?>

		<div class="col-sm-2">
			<div class="form-group">
				<select name="department" class="form-control">
                <option value="all">All</option>
					<option value="0">D5</option>
					<option value="1">D10</option>
					<option value="2">D15</option>
					<option value="3">D20</option>
				</select>
			</div>
		</div>
		<?php echo e(Form::submit('Search', ['class'=>'btn btn-success',"name"=>"Search"])); ?>

		<?php echo e(Form::close()); ?>

	</div>
<?php if($flag==0): ?>

<?php if($class=="all"): ?>
<button data-toggle="collapse" data-target="#demo" style="width:40% ">BE-</button>

   
<div id="demo" class="collapse"  style="width:40%;border:solid 1px ">
<p><?php echo e($dept_stu); ?></p>
<p><?php echo e(count($dept_stu)); ?></p>
</div>
  <?php elseif($class==0): ?>
  <button data-toggle="collapse" data-target="#demo" style="width:40% ">BE-</button>

<div id="demo" class="collapse"  style="width:40%;border:solid 1px ">
<p><?php echo e($dept_stu); ?></p>
<p><?php echo e(count($query)); ?></p>
<div class="container" >
<button class="btn btn-default" data-toggle="collapse" data-target="#demo" style="width:40%">Dipshi</button>
<div id="demo" class="collapse"  style="width:40%;border:solid 1px ">
    
</div>
</div>
  <?php elseif($class==1): ?>
  <button data-toggle="collapse" data-target="#demo" style="width:40% ">BE-</button>

<div id="demo" class="collapse"  style="width:40%;border:solid 1px ">
<p><?php echo e($dept_stu); ?></p>
<p><?php echo e(count($query)); ?></p>
<div class="container" >
<button class="btn btn-default" data-toggle="collapse" data-target="#demo" style="width:40%">Dipshi</button>
<div id="demo" class="collapse"  style="width:40%;border:solid 1px ">
    
</div>
</div>
  <?php elseif($class==2): ?>
  <button data-toggle="collapse" data-target="#demo" style="width:40% ">BE-</button>

<div id="demo" class="collapse"  style="width:40%;border:solid 1px ">
<p><?php echo e($dept_stu); ?></p>
<p><?php echo e(count($query)); ?></p>
<div class="container" >
<button class="btn btn-default" data-toggle="collapse" data-target="#demo" style="width:40%">Dipshi</button>
<div id="demo" class="collapse"  style="width:40%;border:solid 1px ">
    
</div>
</div>


</div>


</div>
<?php endif; ?>
<?php else: ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('faculty.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>