<?php $__env->startSection('page_heading','Bonafide Certificate'); ?>
<?php $__env->startSection('section'); ?>


<script>
setTimeout(fade_out, 1000);

function fade_out() {
  $("#mydiv").fadeOut().empty();
}
</script>

<div class="alert alert-warning alert-dismissible " id="mydiv" role="alert">
	 <i class="fa fa-check"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <?php echo e($success); ?>!!!
</div>

<div class="container" style="font-family:">

<?php if($students->Gender==1): ?>
<p>This is to certify that <b> Mr.<?php echo e($students->FirstName); ?>&nbsp<?php echo e($students->LastName); ?></b> is Bonafide student of our V.E.S Institute of Technology in
<b><?php echo e($students->branch); ?></b> with roll number <b></b> for academic year.
</p>
<?php else: ?>
<p>This is to certify that <b> Ms.<?php echo e($students->FirstName); ?>&nbsp<?php echo e($students->LastName); ?></b> is Bonafide student of our V.E.S Institute of Technology in Ist year Degree of Engg Course in
<b><?php echo e($students->branch); ?></b> with roll number <b></b> for academic year.
<?php endif; ?>
<p>As per our record his/her date of birth <b><?php echo e($students->DOB); ?></b>
and place of birth <b></b>.</p>
<p>To the best of our knowledge.His/She bears good moral character.</p>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>