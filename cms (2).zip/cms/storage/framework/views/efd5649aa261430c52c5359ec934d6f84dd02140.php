<?php $__env->startSection('page_heading','Clearance Approval'); ?>
<?php $__env->startSection('section'); ?>
 <div class="col-sm-12">
      <table class="table table-hover">
         <tr>
            <th>UID</th>
            <th>First Name</th>
            <th>Middle Name</th>
            <th>Last Name</th>

         </tr>
         <?php $__currentLoopData = $page_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo e($detail->UID); ?></td>
            <td><?php echo e($detail->FirstName); ?></td>
            <td><?php echo e($detail->MiddleName); ?></td>
            <td><?php echo e($detail->LastName); ?></td>
            <td><button class = "btn btn-success"> APPROVE </button></td>
            <td><button class ="btn btn-danger"> DECLINE </button></td>
            
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
   
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('faculty.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>