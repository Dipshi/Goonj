<?php $__env->startSection('page_heading','Report Discrepensies'); ?>
<?php $__env->startSection('section'); ?>

<?php echo Form::open(['action'=>'StudentController@reportReportDis','method'=>'GET']); ?>

<?php echo $__env->make('layouts.validation_msgs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="col-sm-1"></div>
<div class="col-sm-10">
    <div class="jumbotron  text-center">
    <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8">
            <div class="form-group">
                    <?php echo e(Form::text('stuname',$students->FirstName.' '.$students->LastName,['class' => 'form-control','placeholder'=>'Student Name','disabled' ,'required'])); ?>

            </div>
            <div class="form-group">
                    <?php echo e(Form::text('stuid',$students->UID,['class' => 'form-control','placeholder'=>'Student ID','disabled'])); ?>

            </div>
            <div class="form-group">
                    <?php echo e(Form::textarea('problem','',['id' => 'article-ckeditor','class' => 'form-control','placeholder'=>'Describe Your Problem' ])); ?>

            </div>
            <br>
            <div class="form group">
                    <?php echo e(Form::submit('APPLY',['class'=>'btn btn-success btn-block'])); ?>

            </div>
        </div>
        </div>
    </div>
    </div>
</div>
</div>
<!--THIS IS FOR APPLICATION OF discrepancies--> 
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>